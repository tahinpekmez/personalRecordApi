package bdp.sample.notebookmanager;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest()
public class NoteBookApplicationTests {

    @Test
    void contextLoads() {
    }

}
